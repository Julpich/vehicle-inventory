# Inventaire VN/VO – PWA (Patched)
- Logs d'erreur caméra détaillés (`name`, `code`, `message`).
- Bannière si l'app est ouverte dans une webview/iframe (avec lien "Ouvrir dans un nouvel onglet").
- `_headers` avec `Permissions-Policy` pour camera.

## Déploiement Netlify
Drag & Drop tout le dossier, ou Import from Git.
Build: (vide)
Publish directory: `.`
